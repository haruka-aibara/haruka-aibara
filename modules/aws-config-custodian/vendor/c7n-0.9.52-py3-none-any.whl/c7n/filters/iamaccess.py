# Copyright The Cloud Custodian Authors.
# SPDX-License-Identifier: Apache-2.0
"""
IAM Resource Policy Checker
---------------------------

When securing resources with iam policies, we want to parse and evaluate
the resource's policy for any cross account or public access grants that
are not intended.

In general, iam policies can be complex, and where possible using iam
simulate is preferrable, but requires passing the caller's arn, which
is not feasible when we're evaluating who the valid set of callers
are.


References

- IAM Policy Evaluation
  https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_evaluation-logic.html

- IAM Policy Reference
  https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_elements.html

- IAM Global Condition Context Keys
  https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_condition-keys.html

"""
import fnmatch
import logging
import json

from c7n.exceptions import PolicyValidationError
from c7n.filters import Filter
from c7n.resolver import ValuesFrom
from c7n.utils import type_schema

log = logging.getLogger('custodian.iamaccess')


def _account(arn):
    # we could try except but some minor runtime cost, basically flag
    # invalids values
    if arn.count(":") < 4:
        return arn
    return arn.split(':', 5)[4]


class PolicyChecker:
    """
    checker_config:
      - check_actions: only check one of the specified actions
      - everyone_only: only check for wildcard permission grants
      - return_allowed: if true, return the statements that are allowed
      - allowed_accounts: permission grants to these accounts are okay
      - whitelist_conditions: a list of conditions that are considered
            sufficient enough to whitelist the statement.
    """
    def __init__(self, checker_config):
        self.checker_config = checker_config

    # Config properties
    @property
    def return_allowed(self):
        return self.checker_config.get('return_allowed', False)

    @property
    def allowed_accounts(self):
        return self.checker_config.get('allowed_accounts', ())

    @property
    def everyone_only(self):
        return self.checker_config.get('everyone_only', False)

    @property
    def check_actions(self):
        return self.checker_config.get('check_actions', ())

    @property
    def whitelist_conditions(self):
        return set(v.lower() for v in self.checker_config.get('whitelist_conditions', ()))

    @property
    def allowed_vpce(self):
        return self.checker_config.get('allowed_vpce', ())

    @property
    def allowed_vpc(self):
        return self.checker_config.get('allowed_vpc', ())

    @property
    def allowed_orgid(self):
        return self.checker_config.get('allowed_orgid', ())

    @property
    def allowed_org_units(self):
        return self.checker_config.get('allowed_org_units', ())

    @property
    def whitelist_patterns(self):
        return self.checker_config.get('whitelist_patterns', ())

    # Policy statement handling
    def check(self, policy_text):
        if isinstance(policy_text, str):
            policy = json.loads(policy_text)
        else:
            policy = policy_text

        allowlist_statements, violations = [], []

        for s in policy.get('Statement', ()):
            if self.handle_statement(s):
                violations.append(s)
            else:
                allowlist_statements.append(s)
        return allowlist_statements if self.return_allowed else violations

    def handle_statement(self, s):
        if (all((self.handle_principal(s),
                 self.handle_effect(s),
                 self.handle_action(s))) and not self.handle_conditions(s)):
            return s

    def handle_action(self, s):
        if self.check_actions:
            actions = s.get('Action')
            actions = isinstance(actions, str) and (actions,) or actions
            for a in actions:
                if fnmatch.filter(self.check_actions, a):
                    return True
            return False
        return True

    def handle_effect(self, s):
        if s['Effect'] == 'Allow':
            return True

    def handle_principal(self, s):
        if 'NotPrincipal' in s:
            return True

        principals = s.get('Principal')
        if not principals:
            return True
        if not isinstance(principals, dict):
            principals = {'AWS': principals}

        # Ignore service principals, merge the rest into a single set
        non_service_principals = set()
        for principal_type in set(principals) - {'Service'}:
            p = principals[principal_type]
            non_service_principals.update({p} if isinstance(p, str) else p)

        if not non_service_principals:
            return False

        principal_ok = True
        for pid in non_service_principals:
            if pid == '*':
                principal_ok = False
            elif self.everyone_only:
                continue
            elif pid.startswith('arn:aws:iam::cloudfront:user'):
                continue
            elif self.whitelist_patterns and any(
                    fnmatch.fnmatch(pid, pattern) for pattern in self.whitelist_patterns):
                continue
            else:
                account_id = _account(pid)
                if account_id not in self.allowed_accounts:
                    principal_ok = False
        return not principal_ok

    def handle_conditions(self, s):
        conditions = self.normalize_conditions(s)
        if not conditions:
            return False

        # Evaluate each condition
        # handle_condition returns True if the condition whitelists (handler returned False)
        # handle_condition returns False if the condition is a violation (handler returned True)
        # handle_condition returns None if handler doesn't exist (unknown condition)

        results = []
        has_whitelisted_org = False

        for c in conditions:
            result = self.handle_condition(s, c)

            # Unknown handler - be conservative and reject immediately
            if result is None:
                return False

            # Track if we have a whitelisted org condition
            if result is True and c['key'] in (
                    'aws:principalorgid', 'aws:resourceorgid',
                    'aws:principalorgpaths'):
                has_whitelisted_org = True

            results.append(result)

        # If all conditions whitelist, return True
        if all(results):
            return True

        # Special case: org ID whitelisted + only wildcard principal conditions fail
        if has_whitelisted_org and not all(results):
            principal_conditions = {
                'aws:principalarn', 'aws:principalaccount',
                'aws:sourceaccount', 'aws:sourcearn',
                's3:dataaccesspointaccount'
            }

            # Check which conditions failed
            for i, c in enumerate(conditions):
                if not results[i]:  # This condition failed (didn't whitelist)
                    if c['key'] not in principal_conditions:
                        # Non-principal condition failed, can't be saved by org ID
                        return False
                    # Check if it's a wildcard or already whitelisted account
                    if not all(
                        '*' in str(v) or _account(str(v)) in self.allowed_accounts
                        for v in c['values']
                    ):
                        # Not a wildcard and not a whitelisted account, it's a real violation
                        return False
            # All failures are wildcard principals, org ID saves it
            return True

        # Some conditions failed and not covered by special case
        return False

    def handle_condition(self, s, c):
        if not c['op']:
            return False
        if c['key'] in self.whitelist_conditions:
            return True
        handler_name = "handle_%s" % c['key'].replace('-', '_').replace(':', '_')
        handler = getattr(self, handler_name, None)
        if handler is None:
            log.warning("no handler:%s op:%s key:%s values:%s" % (
                handler_name, c['op'], c['key'], c['values']))
            return
        return not handler(s, c)

    def normalize_conditions(self, s):
        s_cond = []
        if 'Condition' not in s:
            return s_cond

        conditions = (
            'StringEquals',
            'StringEqualsIgnoreCase',
            'StringLike',
            'ArnEquals',
            'ArnLike',
            'IpAddress',
            'NotIpAddress')
        set_conditions = ('ForAllValues', 'ForAnyValue')

        for s_cond_op in list(s['Condition'].keys()):
            if s_cond_op not in conditions:
                if not any(s_cond_op.startswith(c) for c in set_conditions):
                    continue

            # Loop over all keys under each operator
            for key, value in s['Condition'][s_cond_op].items():
                cond = {'op': s_cond_op}
                cond['key'] = key.lower()
                cond['values'] = (value,) if isinstance(value, str) else value
                s_cond.append(cond)

        return s_cond

    # Condition handlers

    # sns default policy
    def handle_aws_sourceowner(self, s, c):
        return bool(set(map(_account, c['values'])).difference(self.allowed_accounts))

    # AWS Connect default policy on Lex
    def handle_aws_sourceaccount(self, s, c):
        return bool(set(map(_account, c['values'])).difference(self.allowed_accounts))

    # s3 logging
    def handle_aws_sourcearn(self, s, c):
        return bool(set(map(_account, c['values'])).difference(self.allowed_accounts))

    def handle_aws_sourceip(self, s, c):
        return False

    def handle_aws_sourcevpce(self, s, c):
        if not self.allowed_vpce:
            return False
        return bool(set(map(_account, c['values'])).difference(self.allowed_vpce))

    def handle_aws_sourcevpc(self, s, c):
        if not self.allowed_vpc:
            return False
        return bool(set(map(_account, c['values'])).difference(self.allowed_vpc))

    def handle_aws_principalorgid(self, s, c):
        if not self.allowed_orgid:
            return True
        return bool(set(map(_account, c['values'])).difference(self.allowed_orgid))

    def handle_aws_principalorgpaths(self, s, c):
        if not self.allowed_orgid and not self.allowed_org_units:
            return True
        return any(not self._org_path_allowed(v) for v in c['values'])

    def _org_path_allowed(self, condition_ou_path):
        segs = condition_ou_path.split('/')
        org_seg = segs[0]
        if org_seg in self.allowed_orgid:
            return True
        for whitelist_ou_path in self.allowed_org_units:
            w_segs = whitelist_ou_path.strip('/').split('/')
            if w_segs[0] != org_seg:
                continue
            if w_segs[-1] in segs[1:]:
                return True
        return False

    def handle_aws_principalarn(self, s, c):
        """Handle the aws:PrincipalArn condition key."""
        return bool(set(map(_account, c['values'])).difference(self.allowed_accounts))

    def handle_aws_resourceorgid(self, s, c):
        """Handle the aws:resourceOrgID condition key."""

        return bool(set(map(_account, c['values'])).difference(self.allowed_orgid))

    def handle_aws_principalaccount(self, s, c):
        """Handle the aws:PrincipalAccount condition key."""

        return bool(set(map(_account, c['values'])).difference(self.allowed_accounts))

    def handle_s3_dataaccesspointaccount(self, s, c):
        """Handle the s3:DataAccessPointAccount condition key."""

        return bool(set(map(_account, c['values'])).difference(self.allowed_accounts))


class CrossAccountAccessFilter(Filter):
    """Check a resource's embedded iam policy for cross account access.

    Supports a ``whitelist_patterns`` option to skip principals whose identifier
    matches any of the provided `fnmatch
    <https://docs.python.org/3/library/fnmatch.html>`_ patterns.  This is
    useful for ignoring unique identifiers left behind by deleted IAM principals
    (e.g. ``AIDA*`` for deleted IAM users, ``AROA*`` for deleted IAM roles)
    which AWS substitutes into resource policies when the original principal is
    removed.  See `IAM unique identifiers
    <https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_identifiers.html#identifiers-unique-ids>`_
    for the full list of prefixes.

    .. code-block:: yaml

      - type: cross-account
        whitelist_patterns:
          - "AIDA*"
          - "AROA*"

    Supports a ``whitelist_org_units`` option for trusting principals via
    ``aws:PrincipalOrgPaths`` conditions. Each entry must be a full OU path
    starting with the org ID and ending with the OU ID to trust:

    .. code-block:: yaml

      - type: cross-account
        whitelist_org_units:
          - "o-abc1234567/r-ab12/ou-ab12-prod"

    Wildcards (``*``, ``?``) are not permitted in whitelist entries. The org
    ID prefix is required because OU IDs are only unique within an
    organization. A whitelist matches a policy path when the path's leading
    segment equals the whitelist's org ID *and* the whitelist's leaf OU ID
    appears as a literal segment in the path; this means a parent-OU whitelist
    will not implicitly cover policies that only name a descendant OU. List
    each OU level you actually want to trust. ``aws:PrincipalOrgPaths`` matching
    also respects ``whitelist_orgids``. Any policy path whose leading segment
    matches a whitelisted org ID is accepted regardless of the OU whitelist.
    """

    schema = type_schema(
        'cross-account',
        # only consider policies that grant one of the given actions.
        actions={'type': 'array', 'items': {'type': 'string'}},
        # only consider policies which grant to *
        everyone_only={'type': 'boolean'},
        # only consider policies which grant to the specified accounts
        return_allowed={'type': 'boolean'},
        # disregard statements using these conditions.
        whitelist_conditions={'type': 'array', 'items': {'type': 'string'}},
        # white list accounts
        whitelist_from={'$ref': '#/definitions/filters_common/value_from'},
        whitelist={'type': 'array', 'items': {'type': 'string'}},
        whitelist_orgids_from={'$ref': '#/definitions/filters_common/value_from'},
        whitelist_orgids={'type': 'array', 'items': {'type': 'string'}},
        whitelist_org_units_from={'$ref': '#/definitions/filters_common/value_from'},
        whitelist_org_units={'type': 'array', 'items': {'type': 'string'}},
        whitelist_vpce_from={'$ref': '#/definitions/filters_common/value_from'},
        whitelist_vpce={'type': 'array', 'items': {'type': 'string'}},
        whitelist_vpc_from={'$ref': '#/definitions/filters_common/value_from'},
        whitelist_vpc={'type': 'array', 'items': {'type': 'string'}},
        # fnmatch patterns for principals to ignore (e.g. deleted IAM unique IDs)
        whitelist_patterns_from={'$ref': '#/definitions/filters_common/value_from'},
        whitelist_patterns={'type': 'array', 'items': {'type': 'string'}})

    policy_attribute = 'Policy'
    annotation_key = 'CrossAccountViolations'
    allowlist_key = 'CrossAccountAllowlists'

    checker_factory = PolicyChecker

    @staticmethod
    def _validate_org_unit_path(path):
        if '*' in path or '?' in path:
            raise PolicyValidationError(
                "whitelist_org_units entries must not contain wildcards: %r" % path)
        segments = path.strip('/').split('/')
        if len(segments) < 2 or not segments[0].startswith('o-'):
            raise PolicyValidationError(
                "whitelist_org_units entries must be full paths starting with "
                "the org ID (e.g. 'o-abc/r-xyz/ou-target'): %r" % path)

    def validate(self):
        for path in self.data.get('whitelist_org_units', ()):
            self._validate_org_unit_path(path)
        return self

    def process(self, resources, event=None):
        self.everyone_only = self.data.get('everyone_only', False)
        self.return_allowed = self.data.get('return_allowed', False)
        self.conditions = set(self.data.get(
            'whitelist_conditions',
            ("aws:userid", "aws:username")))
        self.actions = self.data.get('actions', ())
        self.accounts = self.get_accounts()
        self.vpcs = self.get_vpcs()
        self.vpces = self.get_vpces()
        self.orgid = self.get_orgids()
        self.org_units = self.get_org_units()
        self.patterns = self.get_whitelist_patterns()
        self.checker_config = getattr(self, 'checker_config', None) or {}
        self.checker_config.update(
            {'allowed_accounts': self.accounts,
             'allowed_vpc': self.vpcs,
             'allowed_vpce': self.vpces,
             'allowed_orgid': self.orgid,
             'allowed_org_units': self.org_units,
             'check_actions': self.actions,
             'everyone_only': self.everyone_only,
             'whitelist_conditions': self.conditions,
             'whitelist_patterns': self.patterns,
             'return_allowed': self.return_allowed})
        self.checker = self.checker_factory(self.checker_config)
        return super(CrossAccountAccessFilter, self).process(resources, event)

    def get_accounts(self):
        owner_id = self.manager.config.account_id
        accounts = set(self.data.get('whitelist', ()))
        if 'whitelist_from' in self.data:
            values = ValuesFrom(self.data['whitelist_from'], self.manager)
            accounts = accounts.union(values.get_values())
        accounts.add(owner_id)
        return accounts

    def get_vpcs(self):
        vpc = set(self.data.get('whitelist_vpc', ()))
        if 'whitelist_vpc_from' in self.data:
            values = ValuesFrom(self.data['whitelist_vpc_from'], self.manager)
            vpc = vpc.union(values.get_values())
        return vpc

    def get_vpces(self):
        vpce = set(self.data.get('whitelist_vpce', ()))
        if 'whitelist_vpce_from' in self.data:
            values = ValuesFrom(self.data['whitelist_vpce_from'], self.manager)
            vpce = vpce.union(values.get_values())
        return vpce

    def get_orgids(self):
        org_ids = set(self.data.get('whitelist_orgids', ()))
        if 'whitelist_orgids_from' in self.data:
            values = ValuesFrom(self.data['whitelist_orgids_from'], self.manager)
            org_ids = org_ids.union(values.get_values())
        return org_ids

    def get_org_units(self):
        org_units = set(self.data.get('whitelist_org_units', ()))
        if 'whitelist_org_units_from' in self.data:
            values = ValuesFrom(self.data['whitelist_org_units_from'], self.manager)
            org_units = org_units.union(values.get_values())
        for path in org_units:
            self._validate_org_unit_path(path)
        return org_units

    def get_whitelist_patterns(self):
        patterns = list(self.data.get('whitelist_patterns', ()))
        if 'whitelist_patterns_from' in self.data:
            values = ValuesFrom(self.data['whitelist_patterns_from'], self.manager)
            patterns = patterns + list(values.get_values())
        return patterns

    def get_resource_policy(self, r):
        return r.get(self.policy_attribute, None)

    def __call__(self, r):
        p = self.get_resource_policy(r)
        if p is None:
            return False
        results = self.checker.check(p)
        if self.return_allowed and results:
            r[self.allowlist_key] = results
            return True

        if not self.return_allowed and results:
            r[self.annotation_key] = results
            return True
